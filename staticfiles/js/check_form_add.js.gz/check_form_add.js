// $('#update-form_plan_materials').on('keyup input',function (e) {
//     // alert("hi");
//     $.post('/update_data_form_add_materials/', $(this).serialize(),function (data) {
//         $('#change_material').html(data)
//     });
//     e.preventDefault();
// });